class Solution:
    def hasCycle(self, N, edges):
