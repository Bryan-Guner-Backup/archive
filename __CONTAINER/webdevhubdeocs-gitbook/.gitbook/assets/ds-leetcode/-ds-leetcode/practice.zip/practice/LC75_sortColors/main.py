class Solution:
    def sortColors(self, nums):
