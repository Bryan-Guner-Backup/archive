class Solution:
    def merge(self, intervals):
