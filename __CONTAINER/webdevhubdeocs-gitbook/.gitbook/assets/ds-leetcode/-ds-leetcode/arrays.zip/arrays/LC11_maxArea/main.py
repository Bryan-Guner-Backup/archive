class Solution:
    def maxArea(self, height):
