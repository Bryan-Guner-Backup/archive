class Solution:
    def productExceptSelf(self, nums):
