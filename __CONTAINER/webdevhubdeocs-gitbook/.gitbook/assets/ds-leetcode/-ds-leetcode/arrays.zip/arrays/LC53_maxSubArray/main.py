class Solution:
    def maxSubArray(self, nums):
