class Solution:
    def containsDuplicate(self, nums):
