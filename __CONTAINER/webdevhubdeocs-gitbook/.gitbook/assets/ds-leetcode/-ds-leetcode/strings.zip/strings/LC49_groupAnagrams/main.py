class Solution:
    def groupAnagrams(self, strs):