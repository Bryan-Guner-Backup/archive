class Solution:
    def lengthOfLongestSubstring(self, s):