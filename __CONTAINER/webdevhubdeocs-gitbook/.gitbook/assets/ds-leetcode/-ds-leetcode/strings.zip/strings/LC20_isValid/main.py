class Solution:
    def isValid(self, s):
