class Solution:
    def isPalindrome(self, s):
