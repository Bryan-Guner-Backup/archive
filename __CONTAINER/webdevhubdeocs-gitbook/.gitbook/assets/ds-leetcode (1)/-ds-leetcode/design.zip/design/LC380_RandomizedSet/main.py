class RandomizedSet:

    def __init__(self):

    def insert(self, val):

    def remove(self, val):

    def getRandom(self):

    def swap(self, arr, i, j):
