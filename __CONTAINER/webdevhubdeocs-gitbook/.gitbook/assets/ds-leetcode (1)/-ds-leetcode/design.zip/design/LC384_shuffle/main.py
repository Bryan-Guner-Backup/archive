import random


class Solution:

    def __init__(self, nums):

    def reset(self):

    def shuffle(self):
