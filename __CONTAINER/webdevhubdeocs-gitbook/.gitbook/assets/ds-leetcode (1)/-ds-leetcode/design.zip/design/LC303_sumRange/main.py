class NumArray:

    def __init__(self, nums):

    def sumRange(self, i, j):
