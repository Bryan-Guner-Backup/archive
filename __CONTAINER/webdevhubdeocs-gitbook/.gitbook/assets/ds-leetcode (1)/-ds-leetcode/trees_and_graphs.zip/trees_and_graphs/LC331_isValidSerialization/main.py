class Solution:
    def isValidSerialization(self, preorder):
