class Solution:
    def maxDepth(self, root):
