class Trie:

    def __init__(self):

    def insert(self, word):

    def search(self, word):

    def startsWith(self, prefix):
