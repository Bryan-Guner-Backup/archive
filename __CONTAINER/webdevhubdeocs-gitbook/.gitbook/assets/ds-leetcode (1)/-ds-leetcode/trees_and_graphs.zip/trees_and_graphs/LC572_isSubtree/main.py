class Solution():
    def isSubtree(self, s, t):
