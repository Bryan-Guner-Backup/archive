class Solution:
    def levelOrder(self, root):
